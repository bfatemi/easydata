#### -- Packrat Autoloader (version 0.4.7-9) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
