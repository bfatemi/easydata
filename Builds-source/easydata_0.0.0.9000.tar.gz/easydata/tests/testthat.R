library(testthat)
library(easydata)

test_check("easydata")
