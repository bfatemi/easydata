#' Internal Helper Functions
#' 
#' @description \code{checkdt} is intended for developers who write functions that 
#'      accept a \code{data.table} as an input. \code{checkdt} performs common checks 
#'      and generates accessible and informative errors (or returns error codes if 
#'      desired), if a data.table fails various checks. An optional character vector 
#'      argument \code{cols} enables an additional check to determine if they exist as 
#'      column names of \code{dt}. See details below the checks that are performed, the
#'      error messages, and if applicable, what error codes are returned.
#'  @details If any of the following are true, a friendly error will be shown and the 
#'      code execution will be stopped:
#'          \itemize{
#'              \item{dt is NULL}
#'              \item{dt is not of class data.table (data.frame)}
#'              \item{dt has 0 rows}
#'              \item{if \code{cols} not valid column names of dt (optional check)}
#'          }
#'     The following error codes are generated when each of the above situations 
#'     occur, \strong{and the flag \code{noerror} is set to TRUE:}
#'          \itemize{
#'              \item{if null:} 999
#'              \item{if class not data.table:} 101
#'              \item{if empty:} 555
#'              \item{if cols not column names:} 422
#'          }
#' 
#' @param dt An object to make common checks to verify it is a valid data.table
#' @param cols An optional character vector of column names to check against column names of dt
#' @return Returns an error code if flag \code{noerror} is TRUE. Otherwise returns NULL or 
#'      code execution is stopped if one of the checks fail. See details for the checks 
#'      that are performed.
#' @keywords internal
#' 
#' @example /examples/example-checkdt.R
#' 
#' @export
#' 
#' @import data.table
checkdt <- function(dt=NULL, cols=NULL, noerror=FALSE){
    if(is.null(dt)){
        if(noerror) 
            return(999)
        else
            stop("no data.table provided", call. = F)
    }
        
    if(!is.data.frame(dt)){
        if(noerror) 
            return(101)
        else
            stop("dt not of class data.table or data.frame", call. = F)
    }
        
    if(nrow(dt)<1){
        if(noerror) 
            return(555)
        else
            stop("no data in dt", call. = F)
    }
        
    if(!is.null(cols)){
        if(sum(!cols %in% colnames(dt))){
            if(noerror) 
                return(555)
            else{
                dne <- paste(cols[which(!cols %in% colnames(dt))], collapse = ", ")
                stop(paste0("the following cols not in data.table: ", dne), call. = F)    
            }
        }
    }
}